# WWII-base
WWII with just the game files, no embedded python 3
